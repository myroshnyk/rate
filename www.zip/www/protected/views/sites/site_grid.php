<?php
$this->widget('zii.widgets.grid.CGridView',array(
    'id'=>'site-grid',
    'dataProvider'=>$model->search(),
    'filter'=>$model,
    'columns'=>array(
            'id',
            'name',
                       
            array(
                'class'=>'CButtonColumn',
                'template' => "{insert}",
                'buttons' => array(
                    "insert" => array(
                        'label' => "выбрать",
                        'options' => array(
                            "class" => "btn btn-mini btn-success",
                            "onclick" => 'selectData("site-grid",$(this).parent().parent().children(":nth-child(1)").text(),$(this).parent().parent().children(":nth-child(2)").text());',
                        )
                    ),
                )
            ),
    ),
));