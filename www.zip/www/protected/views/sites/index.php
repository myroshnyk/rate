<?php
/* @var $this SitesController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Сайты',
);

$this->menu=array(
	array('label'=>'Создать сайт','icon'=>'plus-sign', 'url'=>array('create')),
	array('label'=>'Управление сайтами','icon'=>'edit', 'url'=>array('admin')),
);
?>

<h1>Сайты</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
