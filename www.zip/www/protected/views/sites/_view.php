<?php
/* @var $this SitesController */
/* @var $data Sites */
?>

<div class="view">

	<b><?php echo 'URL сайта'; ?>:</b>
	<?php echo CHtml::encode($data->name); ?>
	<br />


</div>