<?php
/* @var $this SitesController */
/* @var $model Sites */

$this->breadcrumbs=array(
	'Сайты'=>array('index'),
	$model->name,
);

$this->menu=array(
	array('label'=>'Список сайтов', 'icon'=>'list','url'=>array('index')),
	array('label'=>'Создать URL сайта', 'icon'=>'plus-sign','url'=>array('create')),
	array('label'=>'Редактировать URL сайта', 'icon'=>'pencil','url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Удаление URL сайта','icon'=>'trash', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Вы действительно хотите удалить запись?')),
	array('label'=>'Управление сайтами','icon'=>'edit', 'url'=>array('admin')),
);
?>

<h1>Сайт: <?php echo $model->name; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		array('name'=>'name','label'=>'URL сайта'),
		
	),
)); ?>
