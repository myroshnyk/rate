<div class="form">
<?php echo CHtml::beginForm(); ?>
<table>
<tr><th>Имя</th><th>Стоимость</th><th>Количество</th><th>Описание</th></tr>

</table>
 
<?php echo CHtml::submitButton('Сохранить'); ?>
<?php echo CHtml::endForm(); ?>
</div><!-- form -->

