<?php
/* @var $this AsUserCountrySiteController */
/* @var $model AsUserCountrySite */

$this->breadcrumbs=array(
	'As User Country Sites'=>array('index'),
	$model->id,
);

$this->menu=array(
	array('label'=>'List AsUserCountrySite', 'url'=>array('index')),
	array('label'=>'Create AsUserCountrySite', 'url'=>array('create')),
	array('label'=>'Update AsUserCountrySite', 'url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Delete AsUserCountrySite', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Are you sure you want to delete this item?')),
	array('label'=>'Manage AsUserCountrySite', 'url'=>array('admin')),
);
?>

<h1>View AsUserCountrySite #<?php echo $model->id; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		'id',
		'user_id',
		'country_id',
		'site_id',
		'rate',
	),
)); ?>
