<?php
/* @var $this CountriesController */
/* @var $model Countries */

$this->breadcrumbs=array(
	'Страны'=>array('index'),
	$model->name=>array('view','id'=>$model->id),
	'Обновить',
);

$this->menu=array(
	array('label'=>'Список стран', 'icon'=>'list','url'=>array('index')),
	array('label'=>'Создать', 'icon'=>'plus-sign','url'=>array('create')),
	array('label'=>'Просмотр', 'icon'=>'eye-open', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Управление','icon'=>'edit', 'url'=>array('admin')),
);
?>

<h1>Обновить <?php echo $model->name; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>