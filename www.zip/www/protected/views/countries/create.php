<?php
/* @var $this CountriesController */
/* @var $model Countries */

$this->breadcrumbs=array(
	'Страны'=>array('index'),
	'Создать',
);

$this->menu=array(
	array('label'=>'Список стран', 'icon'=>'list','url'=>array('index')),
	array('label'=>'Управление','icon'=>'edit', 'url'=>array('admin')),
);
?>

<h1>Создать</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>