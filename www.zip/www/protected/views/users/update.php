<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Пользователи'=>array('index'),
	$model->username=>array('view','id'=>$model->id),
	'Обновить',
);

$this->menu=array(
	array('label'=>'Список пользователей', 'icon'=>'list','url'=>array('index')),
	array('label'=>'Создать пользователя', 'icon'=>'plus-sign','url'=>array('create')),
	array('label'=>'Просмотр', 'icon'=>'eye-open', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Управление пользователями','icon'=>'edit', 'url'=>array('admin')),
);
?>

<h1>Изменить пользователя: <?php echo $model->username; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>