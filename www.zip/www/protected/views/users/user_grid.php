<?php
$this->widget('zii.widgets.grid.CGridView',array(
    'id'=>'user-grid',
    'dataProvider'=>$model->search(),
    'filter'=>$model,
    'columns'=>array(
            'id',
            'username',
                       
            array(
                'class'=>'CButtonColumn',
                'template' => "{insert}",
                'buttons' => array(
                    "insert" => array(
                        'label' => "выбрать",
                        'options' => array(
                            "class" => "btn btn-mini btn-success",
                            "onclick" => 'selectData("user-grid",$(this).parent().parent().children(":nth-child(1)").text(),$(this).parent().parent().children(":nth-child(2)").text());',
                        )
                    ),
                )
            ),
    ),
));