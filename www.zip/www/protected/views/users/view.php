<?php
/* @var $this UsersController */
/* @var $model Users */

$this->breadcrumbs=array(
	'Пользователи'=>array('index'),
	$model->username,
);

$this->menu=array(
	array('label'=>'Список пользователей', 'icon'=>'list','url'=>array('index')),
	array('label'=>'Создать пользователя', 'icon'=>'plus-sign','url'=>array('create')),
	array('label'=>'Редактировать пользователя', 'icon'=>'pencil','url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Удаление пользователя','icon'=>'trash', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Вы действительно хотите удалить запись?')),
	array('label'=>'Управление пользователями','icon'=>'edit', 'url'=>array('admin')),
);
?>

<h1>Просмотр пользователя: <?php echo $model->username; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
            array('name'=>'username','label'=>'ФИО пользователя'),
	),
)); ?>
