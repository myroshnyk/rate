<?php
/* @var $this SiteController */

$this->pageTitle=Yii::app()->name . ' - Про систему';
$this->breadcrumbs=array(
	'Про систему',
);
?>
<h1>Про систему</h1>
<p>Інформаційна система на підтримку розвитка первинної медичної допомоги на засадах загальної практики — сімейної медицини, яка є одним із головних пріоритетів розбудови національних систем охорони здоров'я, особливо в умовах дефіциту фінансових ресурсів.</p>
<!--<p>This is a "static" page. You may change the content of this page
by updating the file <code><?php echo __FILE__; ?></code>.</p>-->
