<?php
class MainMenu extends CObject {
     private $_main_menu;
            function __construct() {
                $this->_main_menu= array(
                    array(
                    'class'=>'bootstrap.widgets.TbMenu',
                    'items'=>array(
                         array('label'=>'Справочники', 'url'=>'#',
                        'items'=>array(
                            array('label'=>'Пользователи', 'url'=>array('/users'), 'linkOptions'=>array('class'=>'last')),
                            array('label'=>'Страны', 'url'=>array('/countries'),'linkOptions'=>array('class'=>'last')),
                            array('label'=>'Сайты', 'url'=>array('/sites'),'linkOptions'=>array('class'=>'last')),                            
                             )    
                        )
                     )
                    ),
                    
            );
        
    }
    public function get_Menu() {
        
                return $this->_main_menu;

    }
    
}