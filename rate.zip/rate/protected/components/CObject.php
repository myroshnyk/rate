<?php
class CObject {
    //функция устанавливающая "видимость" компонента
    public function isVisibleComp() {
        $show=0;
        $show=Yii::app()->user->isGuest;
        return $show;
    
    }
    // функция возвращающая ФИО текущего пользователя системы
    public static function getFIOUser() {
        return Yii::app()->session->get("fio");
        
    }
}