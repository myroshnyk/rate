<?php
/* @var $this CountriesController */
/* @var $model Countries */

$this->breadcrumbs=array(
	'Страны'=>array('index'),
	$model->name,
);

$this->menu=array(
	array('label'=>'Список стран', 'icon'=>'list','url'=>array('index')),
	array('label'=>'Создать', 'icon'=>'plus-sign','url'=>array('create')),
	array('label'=>'Редактировать', 'icon'=>'pencil','url'=>array('update', 'id'=>$model->id)),
	array('label'=>'Удаление','icon'=>'trash', 'url'=>'#', 'linkOptions'=>array('submit'=>array('delete','id'=>$model->id),'confirm'=>'Вы действительно хотите удалить запись?')),
	array('label'=>'Управление','icon'=>'edit', 'url'=>array('admin')),
);
?>

<h1>Просмотр <?php echo $model->name; ?></h1>

<?php $this->widget('zii.widgets.CDetailView', array(
	'data'=>$model,
	'attributes'=>array(
		array('name'=>'name','label'=>'Наименование'),
	),
)); ?>
