<?php
/* @var $this CountriesController */
/* @var $data Countries */
?>

<div class="view">

	<b><?php echo 'Наименование'; ?>:</b>
	<?php echo CHtml::encode($data->name); ?>
	<br />


</div>