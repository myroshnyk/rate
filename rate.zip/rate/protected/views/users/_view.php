<?php
/* @var $this UsersController */
/* @var $data Users */
?>

<div class="view">
        <!--
	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />
        -->
	<b><?php echo 'Пользователь' ; ?>:</b>
	<?php echo CHtml::encode($data->username); ?>
	<br />


</div>