<?php
/* @var $this SitesController */
/* @var $model Sites */

$this->breadcrumbs=array(
	'Сайты'=>array('index'),
	'Создать',
);

$this->menu=array(
	array('label'=>'Список сайтов', 'icon'=>'list','url'=>array('index')),
	array('label'=>'Управление сайтами','icon'=>'edit', 'url'=>array('admin')),
);
?>

<h1>Создать сайт</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>