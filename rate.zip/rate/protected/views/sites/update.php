<?php
/* @var $this SitesController */
/* @var $model Sites */

$this->breadcrumbs=array(
	'Сайты'=>array('index'),
  	$model->name=>array('view','id'=>$model->id),
	'Обновить',
);

$this->menu=array(
	array('label'=>'Список сайтов', 'icon'=>'list','url'=>array('index')),
	array('label'=>'Создать URL сайта', 'icon'=>'plus-sign','url'=>array('create')),
	array('label'=>'Просмотр', 'icon'=>'eye-open', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Управление сайтом','icon'=>'edit', 'url'=>array('admin')),
);
?>

<h1>Изменить URL <?php echo $model->name; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>