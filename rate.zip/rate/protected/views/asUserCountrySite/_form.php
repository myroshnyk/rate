<?php $form=$this->beginWidget('bootstrap.widgets.TbActiveForm',array(
	'id'=>'user-form',
	'enableAjaxValidation'=>false,
)); ?>

	

	<?php echo $form->errorSummary($model); ?>
     <div class="form-actions">
     <!-- Скрытое поле (hiddenField), в котором лежит user_id -->
    <?php echo $form->textFieldRow($model,'user_id',array('class'=>'span5','style' => 'display:none')); ?>
    <!-- Уведомление о том, что элемент был выбран. Крайне необходим для действия Update, чтобы было видно, что выбрано--> 
        <div class="row">           
            <div id="data-info-user" class="alert alert-success controls span4">
                <i class="icon-file"></i>
                <span class="info ">
                    <?if($model->isNewRecord)echo 'Выберете пользователя'?>
                    <?if(!$model->isNewRecord)echo $model->user_id->username?>
                </span>

            </div>      
            <!-- Сами пишем обертку будущего поля согласно правилам bootstrap-->
            <div class="input-append span1">
                <button class="btn" id="data-select-user" data-loading-text="..." type="button"><i class="icon-list"></i></button>  
            </div>
        </div>
       
     <!-- Скрытое поле (hiddenField), в котором лежит country_id -->
    <?php echo $form->textFieldRow($model,'country_id',array('class'=>'span5','style' => 'display:none')); ?>
    <!-- Уведомление о том, что элемент был выбран. Крайне необходим для действия Update, чтобы было видно, что выбрано--> 
        <div class="row">           
            <div id="data-info-country" class="alert alert-success controls span4">
                <i class="icon-file"></i>
                <span class="info ">
                    <?if($model->isNewRecord)echo 'Выберете страну'?>
                    <?if(!$model->isNewRecord)echo $model->country_id->name?>
                </span>

            </div>      
            <!-- Сами пишем обертку будущего поля согласно правилам bootstrap-->
            <div class="input-append span1">
                <button class="btn" id="data-select-country" data-loading-text="..." type="button"><i class="icon-list"></i></button>  
            </div>
        </div>
	
	<!-- Скрытое поле (hiddenField), в котором лежит site_id -->
    <?php echo $form->textFieldRow($model,'site_id',array('class'=>'span5','style' => 'display:none')); ?>
    <!-- Уведомление о том, что элемент был выбран. Крайне необходим для действия Update, чтобы было видно, что выбрано--> 
        <div class="row">           
            <div id="data-info-site" class="alert alert-success controls span4">
                <i class="icon-file"></i>
                <span class="info ">
                    <?if($model->isNewRecord)echo 'Выберете сайт'?>
                    <?if(!$model->isNewRecord)echo $model->site_id->name?>
                </span>

            </div>      
            <!-- Сами пишем обертку будущего поля согласно правилам bootstrap-->
            <div class="input-append span1">
                <button class="btn" id="data-select-site" data-loading-text="..." type="button"><i class="icon-list"></i></button>  
            </div>
        </div>

	<?php echo $form->textFieldRow($model,'rate',array('class'=>'span2','maxlength'=>10)); ?>
	
   
		<?php $this->widget('bootstrap.widgets.TbButton', array(
			'buttonType'=>'submit',
			'type'=>'primary',
			'label'=>$model->isNewRecord ? 'Создать' : 'Сохранить',
		)); ?>
    </div>

<?php $this->endWidget(); ?>

    <!-- Модальное окошко для выбора нужного материала-->      
<?php $this->beginWidget('bootstrap.widgets.TbModal', array('id'=>'dataModal')); ?>
    <div class="modal-header">
        <a class="close" data-dismiss="modal">×</a>
        <h4><?=Yii::t("menu", "Выберите запись")?></h4>
    </div>
    <div class="modal-body"></div>
    <div class="modal-footer">
        <?php $this->widget('bootstrap.widgets.TbButton', array(
            'label'=>Yii::t("menu", "Отмена"),
            'url'=>'#',
            'htmlOptions'=>array('data-dismiss'=>'modal'),
        )); ?>
    </div>
<?php $this->endWidget(); ?>

 <script> 
     $('#data-select-user').click(function(){
        var buttn = this; 
        $(buttn).button('loading');
        onClickBTN('<?php echo $this->createAbsoluteUrl('/users/loadData')?>',$(buttn));
       });
      
      $('#data-select-country').click(function(){
        var buttn = this; 
        $(buttn).button('loading');
        onClickBTN('<?php echo $this->createAbsoluteUrl('/countries/loadData')?>',$(buttn));
       });
       
       $('#data-select-site').click(function(){
        var buttn = this; 
        $(buttn).button('loading');
        onClickBTN('<?php echo $this->createAbsoluteUrl('/sites/loadData')?>',$(buttn));
       });
    
    function onClickBTN(p_url,btn){
        if ((p_url=='')||(p_url==undefined)){return;}
        $.ajax({
          url: p_url,
          cache: false,
          success: function(html){
            $(".modal-body").html(html);       
            btn.button('reset');
            $('#dataModal').modal().css({
                width: 'auto',
                'margin-left': function () {
                    return -($(this).width() / 2);
                },
            });
          }
          
        });
    };
    
    // Функция для вызова из модального окошка
    function selectData(type,id, name) {
        switch(type){
            case 'user-grid':
                $("#AsUserCountrySite_user_id").val(id);
                $("#data-info-user .info").html(name);
                $("#data-info-user").show();
                break;
            case 'country-grid':
                $("#AsUserCountrySite_country_id").val(id);
                $("#data-info-country .info").html(name);
                $("#data-info-country").show();
                break;
            case 'site-grid':
                $("#AsUserCountrySite_site_id").val(id);
                $("#data-info-site .info").html(name);
                $("#data-info-site").show();
                break;
        }
        
        $('#dataModal').modal("hide");
    }

  </script>