<?php
/* @var $this AsUserCountrySiteController */
/* @var $model AsUserCountrySite */

$this->breadcrumbs=array(
	'As User Country Sites'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List AsUserCountrySite', 'url'=>array('index')),
	array('label'=>'Create AsUserCountrySite', 'url'=>array('create')),
	array('label'=>'View AsUserCountrySite', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage AsUserCountrySite', 'url'=>array('admin')),
);
?>

<h1>Update AsUserCountrySite <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>