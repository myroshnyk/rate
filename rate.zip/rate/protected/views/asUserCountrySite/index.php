<div class="form">
<?php echo CHtml::beginForm(); ?>
<table class="table table-condensed table-bordered">
<tr><th style="display: none;">id</th><th style="display: none;">user_id</th><th style="display: none;">country_id</th><th style="display: none;">site_id</th><th>название</th><th>страна</th><th>url сайта</th><th>отчисления</th></tr>
<tr>
<td colspan="5"> 
<?php $this->widget('bootstrap.widgets.TbButton', array(
    'buttonType'=>'link',
    'type'=>'info',
    'label'=>'Подключить сайты',
    'loadingText'=>'загрузка...',
    'htmlOptions'=>array('id'=>'btnAddSite'),
    'url'=>array('create'),
)); ?>
    
 <?php $this->widget('bootstrap.widgets.TbButton', array(
    'buttonType'=>'submit',
    'type'=>'success',
    'label'=>'Сохранить',
    'loadingText'=>'загрузка...',
    'htmlOptions'=>array('id'=>'btnUpdateRate','class'=>'pull-right'),
     'url'=>array('loadData'),
)); ?>
     </td>
</tr>
<?php>
$data = AsUserCountrySite::model()->findAll(
        array(
            'order'=>'user_id,country_id,site_id'
        )
        );
$username='';
$i=0;
?>

<?php foreach($data as $item): ?>

<tr>
    <td style="display: none;"><?php echo CHtml::activeTextField($item,"[$i]id"); ?></td>
    <td style="display: none;"><?php echo CHtml::activeTextField($item,"[$i]user_id"); ?></td>
    <td style="display: none;"><?php echo CHtml::activeTextField($item,"[$i]country_id"); ?></td>
    <td style="display: none;"><?php echo CHtml::activeTextField($item,"[$i]site_id"); ?></td>
<?php    
    if($username==$item->user->username){
        //$username='';
        echo '<td style="border-top: 0px solid #dddddd;" >'.''.'</td>';
    }
    else {
        $username=$item->user->username;
        echo '<td style="border-bottom: 0px solid #dddddd;" >'.$username.'</td>';
    }
?>
<td><?php echo $item->country->name; ?></td>
<td><?php echo $item->site->name; ?></td>
<td><?php echo CHtml::activeTextField($item,"[$i]rate"); ?></td>

</tr>
<?php $i++; ?>
<?php endforeach; ?>

</table>
 
<?php echo CHtml::endForm(); ?>
</div><!-- form -->




